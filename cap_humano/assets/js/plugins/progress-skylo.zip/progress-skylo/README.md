Vendor
======

Put your 3rd-party files here, but place your application-specific files in the app directory.

